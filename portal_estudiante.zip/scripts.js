console.log('Scripts loaded');
